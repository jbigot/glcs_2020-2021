#include <mpi.h>


#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>

#include <hdf5.h>
#include <hdf5_hl.h>

using std::atol;
using std::cerr;
using std::cout;
using std::endl;
using std::string;
using std::to_string;
using std::vector;

int main( int argc, char* argv[] )
{
	// initialize the MPI library
	MPI_Init(&argc, &argv);
	int rank; MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	
	cerr << argc << endl;
	
	// parse the command line arguments
	size_t block_height;
	size_t block_width;
	switch ( argc ) {
	case 1:
		block_height = 8;
		block_width = 4;
		break;
	case 2: {
		block_height = atol(argv[1]);
		block_width = atol(argv[1]);
	} break;
	case 3: {
		block_height = atol(argv[1]);
		block_width = atol(argv[2]);
	} break;
	default: {
		cerr << "Usage:" << endl;
		cerr << argv[0] << " [<blockheight>] [<blockwidth>]" << endl;
		exit(1);
	}
	}
	
	cout << "block_height = " << block_height << endl;
	cout << "block_width  = " << block_width << endl;
	
	// allocate & initialize data
	vector<double> data(block_height*block_width);
	for (size_t yy=0; yy<block_height; ++yy) {
		for (size_t xx=0; xx<block_width; ++xx) {
			data[yy*block_width+xx] = xx + block_width*rank + 0.000001 * yy;
		}
	}
	
	const string file_name = "my_file_r" + to_string(rank) + ".h5";
	const hid_t h5file = H5Fcreate(file_name.c_str(), H5F_ACC_TRUNC, H5P_DEFAULT, H5P_DEFAULT);
	
	// write data to HDF5!
	const vector<hsize_t> dims { block_height, block_width };
	H5LTmake_dataset_double (h5file, "data", dims.size(), dims.data(), data.data());
	
	H5Fclose(h5file);
	
	// finalize MPI
	MPI_Finalize();
	
	return 0;
}
