# Ex1

* HDF5 est installé dans /usr/lib/x86_64-linux-gnu/hdf5/openmpi, il faut spécifier les chemins à la main
* préférer une cible par étape => permet de paralléliser
 - une cible pour la compilation, une pour l'édition de liens
 - les -I vont à la compilation
 - les -L -l vont à l'édition de liens
* attention aux "wrappers" qui ne se combinent pas
* attention à bien mettre toutes les dépendances (les .h)

# Ex2

* corriger le nom du fichier source
* utiliser le "modern CMake" => cibles fournies par les Find*
 - Cf. https://cmake.org/cmake/help/latest/module/FindMPI.html
   ```
   The module exposes the components C, CXX, MPICXX and Fortran. Each of these controls the various MPI languages to search for. The difference between CXX and MPICXX is that CXX refers to the MPI C API being usable from C++, whereas MPICXX refers to the MPI-2 C++ API that was removed again in MPI-3.
   ```

   ```
   MPI::MPI_<lang>
     Target for using MPI from <lang>.
   ```
 - on fait donc un `find_package(MPI REQUIRED` avec comme composant `CXX`

# Ex3

* La fonction `H5LTmake_dataset_double` permet d'écrire un tableau de doubles
* on utilise un vecteur qui combine: allocation sur le tas + désallocation dynamique
 - utiliser `.data()` pour acceder aux données brutes d'un vecteur
 - tableau standard C => sur la pile, risque de dépassement
 - malloc, attention à la désallocation
* on peut utiliser un `vector` aussi pour les dimensions
 - dans ce cas, on peut utiliser `dims.size()` pour le nombre de dimensions
* on peut utiliser le mot clef `const` devant beaucoup de variables qui évite les erreurs

# Ex4

* il faut inclure `cmath` pour avoir accès à NAN
* il faut corriger la taille du tableau de données: `block_height*full_block_width`
 - dans la dimension `x`, on ajoute les zones fantomes
* il faut supprimer la seconde déclaration de la variable `data`
* il faut décaler la déclaration de la variable `rank` avant sa première utilisation
* On ne peut plus utiliser les fonctions de H5LT qui ne fonctionne que quand on écrit un tableau entier sur disque
* On va donc créer le dataspace à la main dans le fichier avec `H5Screate_simple` et le dataset avec `H5Dcreate`
 - on peut utiliser les valeurs par défaut des property lists avec H5P_DEFAULT
* en mémoire on crée aussi le dataspace avec `H5Screate_simple` qui représente le tableau entier (avec zones fantomes)
 - on sélectionne ensuite la partie à écrire avec `H5Sselect_hyperslab(..., H5S_SELECT_SET`
 - on peut passer NULL pour les paramètres `stride` et `bloc` pour ne spécifier que `start` et `count`
 - la partie à écrire commence après la zone fantome en `x` (`start=ghost`), sa taille exclue la zone fantome
* lors de l'ecriture on doit spécifier cette sélection pour le memory space, on peut utiliser `H5S_ALL` dans le fichier
* Il faut bien penser à fermer tous les objects HDF5 qu'on a créé (en ordre inverse de création en général)
