#include <mpi.h>

#include <cmath>
#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>

#include <hdf5.h>

using std::atol;
using std::cerr;
using std::cout;
using std::endl;
using std::string;
using std::to_string;
using std::vector;

int main( int argc, char* argv[] )
{
	// initialize the MPI library
	MPI_Init(&argc, &argv);
	
	cerr << argc << endl;
	
	// parse the command line arguments
	size_t block_height;
	size_t block_width;
	size_t ghost;
	switch ( argc ) {
	case 1: {
		block_height = 8;
		block_width = 4;
		ghost = 1;
	}	break;
	case 2: {
		block_height = atol(argv[1]);
		block_width = atol(argv[1]);
		ghost = 1;
	} break;
	case 3: {
		block_height = atol(argv[1]);
		block_width = atol(argv[2]);
		ghost = 1;
	} break;
	case 4: {
		block_height = atol(argv[1]);
		block_width = atol(argv[2]);
		ghost = atol(argv[3]);
	} break;
	default: {
		cerr << "Usage:" << endl;
		cerr << argv[0] << " [<blockheight>] [<blockwidth>] [<ghostzie>]" << endl;
		exit(1);
	}
	}
	
	cout << "block_height = " << block_height << endl;
	cout << "block_width  = " << block_width << endl;
	cout << "ghost  = " << ghost << endl;
	
	// full width, including ghost
	const size_t full_block_width = block_width + 2*ghost;
	
	// allocate & initialize data
	vector<double> data(full_block_width * block_height);
	for (size_t yy=0; yy<block_height; ++yy) {
		for (size_t xx=0; xx<full_block_width; ++xx) {
			data[yy*full_block_width+xx] = NAN;
		}
	}
	
	int rank; MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	for (size_t yy=0; yy<block_height; ++yy) {
		for (size_t xx=0; xx<block_width; ++xx) {
			data[yy*full_block_width+xx+ghost] = xx + block_width*rank + 0.000001 * yy;
		}
	}
	
	const string file_name = "my_file_r" + to_string(rank) + ".h5";
	const hid_t h5file = H5Fcreate(file_name.c_str(), H5F_ACC_TRUNC, H5P_DEFAULT, H5P_DEFAULT);
	
	// create the file dataspace
	const vector<hsize_t> file_dims { block_height, block_width };
	const hid_t file_space = H5Screate_simple(file_dims.size(), file_dims.data(), NULL);
	
	// create the dataset
	const hid_t dataset = H5Dcreate(h5file, "data", H5T_NATIVE_DOUBLE, file_space, H5P_DEFAULT, H5P_DEFAULT, H5P_DEFAULT);
	
	// create the memory dataspace
	const vector<hsize_t> mem_dims { block_height, full_block_width };
	const hid_t mem_space =  H5Screate_simple(mem_dims.size(), mem_dims.data(), NULL);
	
	// select the region we want to write in the memory dataspace
	const vector<hsize_t> mem_start { 0, ghost };
	const vector<hsize_t> mem_count { block_height, block_width };
	H5Sselect_hyperslab(mem_space, H5S_SELECT_SET, mem_start.data(), NULL, mem_count.data(), NULL );
	
	// write data to HDF5!
	H5Dwrite(dataset, H5T_NATIVE_DOUBLE, mem_space, H5S_ALL, H5P_DEFAULT, data.data());
	
	H5Sclose(mem_space);
	H5Dclose(dataset);
	H5Sclose(file_space);
	H5Fclose(h5file);
	
	// finalize MPI
	MPI_Finalize();
	
	return 0;
}
