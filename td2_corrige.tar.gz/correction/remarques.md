
# Ex5

* pour l'ouverture du fichier il va falloir passer une file access property list spécifiant un accès parallèle
 - on la crée avec `H5Pcreate(H5P_FILE_ACCESS)` puis on configure l'ouverture parallèle avec `H5Pset_fapl_mpio(..., MPI_COMM_WORLD, MPI_INFO_NULL)`
 - on la passe lors de l'ouverture du ficher
 - on pense à bien la fermer ensuite
* lors de la création du dataspace dans le fichier, on doit représenter les données complètes
 - on multiplie la taille par notre rang MPI (`MPI_Comm_size`)
* il va ensuite falloir sélectionner la partie à écrire localement
 - comme pour la sélection en mémoire, on utilise `H5Sselect_hyperslab(..., H5S_SELECT_SET`
 - comme pour la sélection en mémoire, on passe NULL pour `stride` et `bloc`
 - la taille du bloc local est la taille sans zone fantome
 - la position est décalé d'autant de blocs que notre rang MPI
* pour que l'écriture se fasse en parallèle, il va faloir passer une data transfer property list
 - on la crée avec `H5Pcreate(H5P_DATASET_XFER)`
 - on spécifie une écriture collective avec `H5Pset_dxpl_mpio(..., H5FD_MPIO_COLLECTIVE)`
* en plus de passer cette property list lors de l'écriture, il faut bien penser à spécifier les sélections en mémoire et dans le fichier
